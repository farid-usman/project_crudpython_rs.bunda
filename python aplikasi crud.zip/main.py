import mysql.connector
import os

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="db_permata"

)
# if (db.is_connected):
#    print ("database berhasil konek")
# else:
#    print("Gagal terkonek")

# masukkan data untuk pertama kali


def insert_data(db):
    no_pasien = input("masukkan No Pasien: ")
    nama_pasien = input("masukkan Nama Pasien: ")
    alamat_pasien = input("masukkan Alamat Pasien: ")
    telp_pasien = input("Masukkan No Telepon Pasien: ")

    val = (no_pasien, nama_pasien, alamat_pasien, telp_pasien)
    sql = "INSERT INTO tb_pasien (no_pasien, nama_pasien, alamat_pasien, telp_pasien) VALUES (%s, %s, %s, %s)"

    #db.cursor().execute(sql, val)
    cursor = db.cursor()

    cursor.execute(sql, val)

    db.commit()

    print("{} data berhasil disimpan".format(cursor.rowcount))


# insert_data(db)

# menampilkan hasil data yg sudah di input di awal


def show_data(db):
    cursor = db.cursor()
    sql = "SELECT * FROM tb_pasien"
    cursor.execute(sql)
    hasil = cursor.fetchall()

    if cursor.rowcount == 0:
        print("tidak ada Data yang di masukkan")
    else:
        for data in hasil:
            print("", data)


# show_data(db)

# update data yang sudah di input dan di tampilkan diatas


def update_data(db):
    cursor = db.cursor()
    show_data(db)
    _id = input("Pilih Id data yang ingin diubah: ")
    no_pasien = input("Masukkan no pasien Baru: ")
    nama_pasien = input("Masukkan Nama Pasien Baru: ")
    alamat_pasien = input("Masukkan Alamat Pasien Baru: ")
    telp_pasien = input("Masukkan Telp Pasien Baaru: ")

    sql = "UPDATE tb_pasien SET no_pasien=%s, nama_pasien=%s, alamat_pasien=%s, telp_pasien=%s WHERE id=%s"
    val = (no_pasien, nama_pasien, alamat_pasien, telp_pasien, _id)

    cursor.execute(sql, val)

    db.commit()
    print("{} data berhasil diubah".format(cursor.rowcount))

    show_data(db)


# dibawah ini update_data(db)
# menghapus data yang sudah di input, ditampilkan.
def delete_data(db):
    cursor = db.cursor()
    show_data(db)
    _id = input("Pilih Id data yang akan dihapus: ")
    sql = "DELETE FROM tb_pasien WHERE id=%s"
    val = (_id,)
    cursor.execute(sql, val)
    db.commit()
    print("{} data berhasil dihapus!! ".format(cursor.rowcount))

    # kita tampilkan lagi apakah data berhasil dihapus.
    show_data(db)


# delete_data(db)


def search_data(db):
    cursor = db.cursor()
    keyword = input("Masukkan Kata Kunci yang akan dicari: ")
    sql = "SELECT * FROM tb_pasien WHERE no_pasien LIKE %s OR nama_pasien LIKE %s"
    val = ("%{}%".format(keyword), "%{}%".format(keyword))
    cursor.execute(sql, val)

    hasil = cursor.fetchall()
    if cursor.rowcount == 0:
        print("Tidak ada data yang")
    else:
        for data in hasil:
            print(data)


def show_menu(db):
    print("\n\n.:Program CRUD dan Pencarian Data Pasien:.\n")
    print("1. Insert Data ")
    print("2. Show Data")
    print("3. Update Data")
    print("4. Delete Data")
    print("5. Search Data")
    print("0. Exit ")
    print("--------------------------------------------")

    # os.system("clear")  # untuk mac os
    # os.system("cls") #untuk windows

    menu = input("Pilih Menu: ")

    if menu == "1":
        insert_data(db)
    elif menu == "2":
        show_data(db)
    elif menu == "3":
        update_data(db)
    elif menu == "4":
        delete_data(db)
    elif menu == "5":
        search_data(db)
    elif menu == "0":
        exit()
    else:
        print("pilihan tidak sesuai")


if __name__ == "__main__":
    while(True):
        show_menu(db)
